package com.stg.spring.batch.config;

import org.springframework.batch.item.ItemProcessor;

import com.stg.spring.batch.entity.Customer;
import com.stg.spring.batch.exception.ResourceNotFound;

public class CustomerProcessor implements ItemProcessor<Customer,Customer> {

    @Override
    public Customer process(Customer customer) throws Exception {
        if(customer.getEmail().contains("@") && 
        		customer.getFirstName().toLowerCase().startsWith("m") && 
        		customer.getGender().equalsIgnoreCase("male"))
        {
       		      	
            return customer;
//            getCountry().equals("United States")) 
        }
        else{
        	
            throw new ResourceNotFound("No Matching data found");
            
//            Exception("No Matching data found"+ customer.toString());
        }
    }
}
