package com.stg.spring.batch;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableBatchProcessing
@ComponentScan(basePackages = "com.stg.spring.batch")
public class BatchProcessingDemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext runBoot = SpringApplication.run(BatchProcessingDemoApplication.class, args);

		printBeans(runBoot);
		for (String s : runBoot.getBeanDefinitionNames()) {
			System.out.println(s);
		}

	}

	private static void printBeans(ConfigurableApplicationContext context) {
		String[] beanDefn = context.getBeanDefinitionNames();
		for (String s : beanDefn)
			System.out.println(s);
	}

}
