package com.stg.spring.batch.config;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stg.spring.batch.entity.Customer;
import com.stg.spring.batch.repository.CustomerRepository;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class CustomerWriter implements ItemWriter<Customer> {
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public void write(List<? extends Customer> items) throws Exception {
		
		log.info("writer process started {}", Thread.currentThread().getName());
		
		customerRepository.saveAll(items);
		
		
	}

}
