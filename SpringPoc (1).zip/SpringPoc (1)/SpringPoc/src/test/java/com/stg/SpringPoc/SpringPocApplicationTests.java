package com.stg.SpringPoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
