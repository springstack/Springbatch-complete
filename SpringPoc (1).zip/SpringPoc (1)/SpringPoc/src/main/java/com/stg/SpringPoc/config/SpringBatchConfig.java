package com.stg.SpringPoc.config;

import com.stg.SpringPoc.component.EmployeeProcessor;
import com.stg.SpringPoc.component.EmployeeWriter;
import com.stg.SpringPoc.component.listener.CustomSkipListener;
import com.stg.SpringPoc.entity.Employee;
import com.stg.SpringPoc.partition.CustomPartitioner;
import com.stg.SpringPoc.policy.CustomSkipPolicy;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.partition.support.TaskExecutorPartitionHandler;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

    @Value("classpath:org/springframework/batch/core/schema-drop-postgresql.sql")
    private Resource dropRepositoryTables;

    @Value("classpath:org/springframework/batch/core/schema-postgresql.sql")
    private Resource dataRepositorySchema;

    @Bean(name="batchJob")
    public Job job(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new JobBuilder("importEmployeeFromCsvToDb", jobRepository)
                .preventRestart()
                .start(step1(jobRepository,transactionManager))
                .build();
    }
    @Bean(name="step1")
    public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("step1", jobRepository)
                .<Employee, Employee>chunk(10, transactionManager)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                //.taskExecutor(taskExecutor())
                .faultTolerant()
                .skip(FlatFileParseException.class)
//                .skipLimit(2)
//                .noSkip(FlatFileParseException.class)
                .skipPolicy(skipPolicy())
                .listener(skipListener())

                .build();
    }

    @Bean(name="masterStep")
    public Step masterStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("masterStep", jobRepository)
                .partitioner(slaveStep1(jobRepository,transactionManager).getName(), partitioner())
                .partitionHandler(partitionerHandler(jobRepository, transactionManager))

                .build();
    }

    @Bean
    public CustomPartitioner partitioner(){return new CustomPartitioner();}

    public PartitionHandler partitionerHandler(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        TaskExecutorPartitionHandler taskExecutorPartitionHandler = new TaskExecutorPartitionHandler();
        taskExecutorPartitionHandler.setGridSize(4);
        taskExecutorPartitionHandler.setTaskExecutor(taskExecutor());
        taskExecutorPartitionHandler.setStep(slaveStep1(jobRepository, transactionManager));

        return taskExecutorPartitionHandler;
    }

    @Bean(name="slaveStep1")
    public Step slaveStep1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("step1", jobRepository)
                .<Employee, Employee>chunk(10, transactionManager)
                .reader(reader())
                .processor(processor())
                .writer(writer())
//                .taskExecutor(asyncTaskExecutor())

                .build();
    }
    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(4);
        taskExecutor.setCorePoolSize(4);
        taskExecutor.setQueueCapacity(4);

        return taskExecutor;

    }
    @Bean(name="transactionManager")
    public PlatformTransactionManager getTransactionManager(){
        return new JpaTransactionManager();
    }

    @Bean(name="jobRepository")
    public JobRepository getJobRepository() throws Exception{
        JobRepositoryFactoryBean factory=new JobRepositoryFactoryBean();
        factory.setDataSource(postgresDataSource());
        factory.setTransactionManager(getTransactionManager());
        factory.afterPropertiesSet();
        return factory.getObject();

    }
    public DataSource postgresDataSource(){
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl("jdbc:postgresql://localhost:5432/postgres");
        dataSource.setUsername("postgres");
        dataSource.setPassword("phantom");

        dataSourceInitializer(dataSource);

        return dataSource;
    }

    @Bean
    public DataSourceInitializer dataSourceInitializer(DataSource dataSource) {

        ResourceDatabasePopulator databasePopulator = new ResourceDatabasePopulator();
        databasePopulator.addScript(dropRepositoryTables);
        databasePopulator.addScript(dataRepositorySchema);
        databasePopulator.setIgnoreFailedDrops(false);

        DataSourceInitializer initializer = new DataSourceInitializer();
        initializer.setDataSource(dataSource);
        initializer.setDatabasePopulator(databasePopulator);

        return initializer;
    }

    @Bean
    public FlatFileItemReader<Employee> reader(){
        return new FlatFileItemReaderBuilder<Employee>()
                .resource(new ClassPathResource("employee_data.csv"))
                .name("employeeReader")
                .linesToSkip(1)
                .lineMapper(lineMapper())


                .build();
    }

    private LineMapper<Employee> lineMapper(){

        DefaultLineMapper<Employee> lineMapper2 =  new DefaultLineMapper<>();

        DelimitedLineTokenizer lineTokenizer= new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames("id", "name", "username", "gender", "salary");

        BeanWrapperFieldSetMapper<Employee> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(Employee.class);
        lineMapper2.setLineTokenizer(lineTokenizer);
        lineMapper2.setFieldSetMapper(fieldSetMapper);

        return lineMapper2;

    }

    @Bean
    public EmployeeProcessor processor(){
        return new EmployeeProcessor();
    }

    @Bean
    public EmployeeWriter writer(){
        return new EmployeeWriter();
    }

    @Bean
    public TaskExecutor asyncTaskExecutor(){
        SimpleAsyncTaskExecutor simpleAsyncTaskExecutor = new SimpleAsyncTaskExecutor();
        simpleAsyncTaskExecutor.setConcurrencyLimit(10);
        return simpleAsyncTaskExecutor;
    }

    @Bean
    public SkipPolicy skipPolicy(){
        return new CustomSkipPolicy();
    }
    @Bean
    public SkipListener skipListener(){
        return new CustomSkipListener();
    }
}

