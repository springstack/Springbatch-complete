package com.stg.SpringPoc.component.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stg.SpringPoc.entity.Employee;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;
import org.springframework.stereotype.Component;

@Component
public class CustomSkipListener implements SkipListener<Employee, Number> {

    Logger logger = LoggerFactory.getLogger(CustomSkipListener.class);
    @Override
    public void onSkipInRead(Throwable throwable){
        logger.info("A failure on read{}", throwable.getMessage());
    }
    @Override
    public void onSkipInWrite(Number item, Throwable throwable) {
        logger.info("A Failure on write {}, {}", throwable.getMessage(), item);
    }

   @SneakyThrows
   @Override
    public void onSkipInProcess(Employee employee, Throwable throwable) {
        logger.info("Item {} was skipped due to exception {}", new ObjectMapper().writeValueAsString(employee),
                throwable.getMessage());

    }
}
