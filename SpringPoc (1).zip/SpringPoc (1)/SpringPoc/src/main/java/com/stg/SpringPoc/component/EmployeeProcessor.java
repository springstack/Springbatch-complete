package com.stg.SpringPoc.component;

import com.stg.SpringPoc.entity.Employee;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class EmployeeProcessor implements ItemProcessor<Employee, Employee> {


    @Override
    public Employee process(Employee employee) throws Exception {
        Long salary = employee.getSalary();

        if(salary>=50000) {
            return employee;
        }
        return null;
    }
}
